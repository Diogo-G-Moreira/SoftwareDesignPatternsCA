/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage.Employee;

import lawmanage.Email.EmailAddress;
import lawmanage.Employee.Employee;

/**
 *
 * @author Diogo
 */
public class Lawyer extends Employee {
    
    public Lawyer(String name, EmailAddress email, String id)
    {
        this.name = name;
        this.email = email;
        this.id = id;
        permissions = 2;
        
       
    }
    
    
    
    
}
