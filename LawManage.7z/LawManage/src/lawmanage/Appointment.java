/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.joda.time.DateTime;

/**
 *
 * @author Diogo
 */
public class Appointment {
    
    String typeMeeting;
    String description;
    DateTime date = new DateTime();
    ArrayList <Employee> associatedParties = new ArrayList();
    boolean kept = true;
    
    public Appointment(String meeting, String desc, DateTime date) throws ParseException
    { 
        this.typeMeeting = meeting;
        this.description = desc;
        this.date = date;
    }

    public void setTypeMeeting(String typeMeeting) {
        this.typeMeeting = typeMeeting;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(DateTime date) {
        this.date = date;
    }

    public void setAssociatedParties(ArrayList<Employee> associatedParties) {
        this.associatedParties = associatedParties;
    }

    public void setKept(boolean kept) {
        this.kept = kept;
    }

    public String getTypeMeeting() {
        return typeMeeting;
    }

    public String getDescription() {
        return description;
    }

    public DateTime getDate() {
        return date;
    }
    
    public String getDateString() {
        return date.toString("yyyy-MM-dd");
    }

    public ArrayList<Employee> getAssociatedParties() {
        return associatedParties;
    }

    public boolean isKept() {
        return kept;
    }
    
    
    public void addParticipant(Employee emp)
    {
        associatedParties.add(emp);
    }
    
    
}
