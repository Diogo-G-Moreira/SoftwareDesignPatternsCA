/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage.Appointment;

import lawmanage.Appointment.Appointment;
import lawmanage.Employee.Employee;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;
import org.joda.time.DateTime;

/**
 *
 * @author Diogo
 */
public class AppointmentManager {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    AppointmentObserver observer = new AppointmentObserver();
    public AppointmentManager(ArrayList <Appointment> appList, ArrayList <Employee> empList) throws ParseException, IOException
    {
   while(true){
       boolean end = false;
        System.out.println("APPOINTMENT MANAGER\n\nWhat would you like to do?\n1.Edit Appointments\n2.Add Appointment\n3.Delete Appointment\n4.Exit");
            String input = reader.readLine();
        switch (input) {
                case "1":  editAppointment(appList, empList);
                     break;
            case "2":  addAppointment(appList, empList);
                     break;
            case "3": deleteAppointment(appList);
                     break;
          case "4":  end = true;
                     break;      
            default: System.out.println("Invalid Choice, Try Again");
                     break;
         }
        if(end == true){break;}
   }
          }
        private void editAppointment(ArrayList <Appointment> list, ArrayList <Employee> empList) throws IOException
        {
            int app = selectAppointment(list);
            System.out.println("EDIT APPOINTMENT \n\nWhat would you like to change?\n1.Name\n2.Desc\n3.Date\n4.Add Attendees\n5.Exit");
            String input = reader.readLine();
            System.out.println("\n\n\n\n\n\n\n\n\n");
            boolean end = false;
            while(true){
        switch (input) {
                case "1": System.out.println("Whats the new name?");input = reader.readLine();list.get(app).setTypeMeeting(input);observer.alert(list.get(app), list.get(app).getAssociatedParties()); 
                     break;
            case "2":  System.out.println("Whats the new Description?");input = reader.readLine();list.get(app).setDescription(input);observer.alert(list.get(app), list.get(app).getAssociatedParties());
                     break;
            case "3": System.out.println("Whats the new year, month, day?");String year = reader.readLine();String month = reader.readLine();String day = reader.readLine();observer.alert(list.get(app), list.get(app).getAssociatedParties());
            list.get(app).setDate(new DateTime(Integer.parseInt(year),Integer.parseInt(month) , Integer.parseInt(day),0,0,0));
                     break;
            case "4":ArrayList<Employee> associated = new ArrayList<Employee>(); while(true){int emp = addAttendee(empList);
                associated.add(empList.get(emp));

                System.out.println("Do you wish to keep adding more attendees?");
                String answer = reader.readLine();
               if (answer.equals("n") || answer.equals("N")){
                  break;
               }
                }
            observer.alert(list.get(app), associated);
            for(int i = 0; i < associated.size();i++)
            {
                list.get(app).addParticipant(associated.get(i));
            }
            
            System.out.println("\n\n\n\n\n\n\n\n\n");
                break;
        case"5": end = true;break;
         }
            if (end ==true)
            {
                break;
            }
            } 
        }
             
        
        private int selectAppointment(ArrayList <Appointment> list) throws IOException
        {
            System.out.println("Select Appointment");
            int size = list.size();
            for (int i = 0; i < list.size();i++)
            {
                System.out.println(i+". "+list.get(i).getTypeMeeting()+"  -  Date: "+list.get(i).getDateString());
            }
            System.out.println("\n");
            String input = reader.readLine();
            return Integer.parseInt(input);
            
        }
        
        private int selectEmployee(ArrayList <Employee> list) throws IOException
        {
            System.out.println("Select Employee");
            int size = list.size();
            for (int i = 0; i < list.size();i++)
            {
                System.out.println(i+". "+list.get(i).getName());
            }
            System.out.println("\n");
            String input = reader.readLine();
            return Integer.parseInt(input);
            
        }
        
        private void addAppointment(ArrayList <Appointment> list,ArrayList <Employee> empList ) throws ParseException, IOException
        {
            System.out.println("ADD APPOINTMENT \n\nInput Meeting type.");
            String meeting = reader.readLine();
            System.out.println("Input Desc type.");
            String desc= reader.readLine();
            System.out.println("Whats the new year, month, day?");
            String year = reader.readLine();
            String month = reader.readLine();
            String day = reader.readLine();
            ArrayList<Employee> associated = new ArrayList<Employee>();
            System.out.println("Adding attendees.. ");
            while (true)
            {
                int emp = addAttendee(empList);
                associated.add(empList.get(emp));

                System.out.println("Do you wish to keep adding more attendees?");
                String answer = reader.readLine();
               if (answer.equals("n") || answer.equals("N")){
                  break;
               }

            }
            
            Appointment apt = new Appointment(meeting, desc,new DateTime(Integer.parseInt(year),Integer.parseInt(month) , Integer.parseInt(day),0,0,0),associated );
            list.add(apt);
            observer.alert(apt, associated);
            System.out.println("\n\n\n\n\n\n\n\n\n");
      
        }
        
        private void deleteAppointment(ArrayList <Appointment> list) throws IOException
        {
            int app = selectAppointment(list);
            list.remove(app);
            System.out.println("DELETE APPOINTMENT \n\nAppointment deleted..");       
  
        }
            
        private int addAttendee( ArrayList <Employee> empList) throws IOException
        {
            int emp = selectEmployee(empList);
               System.out.println("Attendee added..");     
            return emp;
           
  
        }
        
}
