/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage.Appointment;

import java.util.ArrayList;
import lawmanage.Email.EmailCreator;
import lawmanage.Employee.Employee;

/**
 *
 * @author Diogo
 */
public class AppointmentObserver {
    
    public void alert(Appointment app, ArrayList<Employee> emps){
        
       for(int i = 0; i < emps.size();i++)
       {
           new EmailCreator(app, emps.get(i));
       }
  
    } 

    
    
    
}
