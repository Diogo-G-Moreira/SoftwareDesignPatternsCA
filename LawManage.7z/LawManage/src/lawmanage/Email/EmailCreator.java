/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage.Email;

import lawmanage.Email.EmailAddress;
import lawmanage.Email.Email;
import lawmanage.Employee.Employee;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import lawmanage.Appointment.Appointment;
import org.joda.time.DateTime;

/**
 *
 * @author Diogo
 */
public class EmailCreator {
    ArrayList <EmailAddress> senders;
    String content;
    String topic;
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
   public EmailCreator(ArrayList <Employee> list) throws IOException {
    
    senders = new ArrayList<EmailAddress>();   
    System.out.println("Write topic of email");
    this.topic = reader.readLine();   
    System.out.println("Write content of email");
    this.content = reader.readLine();
    while(true)
    {
        selectSenders(list);
        System.out.println("More Senders? Y/N");
        String reply = reader.readLine();   
        if (reply.equals("n") || reply.equals("N"))
        {
            break;
        }
    }
    for(int i = 0;i<senders.size();i++)
    {
        Email email = new Email(senders.get(i), new DateTime(), this.content, this.topic);
        senders.get(i).addInbox(email);
    }
    System.out.println("Emails Sent!");
    
}
   
   public EmailCreator (Appointment apt, Employee emp){
      EmailAddress sender = emp.getEmail();
      DateTime date = apt.getDate();
      String topic = apt.getTypeMeeting();
      String content = apt.getDescription();
       Email email = new Email(sender, date, topic, content);
       emp.getEmail().addInbox(email);
       
   }
  
   
    private void selectSenders(ArrayList <Employee> list) throws IOException
        {
            System.out.println("Select Sender");
            int size = list.size();
            for (int i = 0; i < list.size();i++)
            {
                System.out.println(i+". "+list.get(i).getName());
            }
            System.out.println("\n");
            String input = reader.readLine();
            senders.add(list.get(Integer.parseInt(input)).getEmail());
            
        }
    
}
