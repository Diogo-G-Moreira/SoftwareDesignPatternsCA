/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import java.util.ArrayList;

/**
 *
 * @author Diogo
 */
public class EmailAddress {
    
    String address;
    ArrayList <Email> inbox;
    
    public EmailAddress(String address)
    {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public ArrayList<Email> getInbox() {
        return inbox;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setInbox(ArrayList<Email> inbox) {
        this.inbox = inbox;
    }
    public void addInbox(Email email) {
        this.inbox.add(email);
    }
    
    
}
