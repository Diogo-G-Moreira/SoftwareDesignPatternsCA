/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import org.joda.time.DateTime;

/**
 *
 * @author Diogo
 */
public class EmailManager {
 
    
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    public EmailManager(ArrayList <Appointment> appList, ArrayList <Employee> empList,String user) throws ParseException, IOException
    {
        
   while(true){
       boolean end = false;
        System.out.println("EMAIL MANAGER\n\nWhat would you like to do?\n1.New Email\n2.View Emails\n3.Delete Emails\n4.Exit");
            String input = reader.readLine();
        switch (input) {
            case "1":  newEmail(empList);
                     break;
            case "2":  viewEmails(empList, user);
                     break;
            case "3": deleteEmail(empList, user);
                     break;
            case "4":  end = true;
                     break;    
            default: System.out.println("Invalid Choice, Try Again");
                     break;
         }
        if(end == true){break;}
   }
          }
    
    
    private void newEmail(ArrayList <Employee> list) throws IOException
        {
            System.out.println("NEW EMAIL \n\n");
            new EmailCreator(list);
        }
    
        private void viewEmails(ArrayList <Employee> list, String user) throws IOException
        {
            System.out.println("****INBOX***** \n\n");
            boolean noEmails = true;
            
            for (int i = 0; i < list.size();i++)
            {
                for (int j = 0; j <list.get(i).getEmail().getInbox().size();j++)
                {
                    if(list.get(i).getId().equals(user))
                    {
                         System.out.println(j+". "+list.get(i).getEmail().getInbox().get(j).getSender().getAddress()+"  -  Date: "+list.get(i).getEmail().getInbox().get(j).getDate());
                         noEmails = false;
                              
                    }
                } 
            if(noEmails == false){
                System.out.println("Pick an Email to read \n\n");
                String input = reader.readLine();
                System.out.println("\n\n\n\nSender: "+list.get(i).getEmail().getInbox().get(Integer.parseInt(input)).getSender().getAddress());
              //  System.out.println("Recipient: "+list.get(i).getEmail().getInbox().get(Integer.parseInt(input)).getRecipient().getAddress());
                System.out.println("Date: "+list.get(i).getEmail().getInbox().get(Integer.parseInt(input)).getDate());
                System.out.println("Topic: "+list.get(i).getEmail().getInbox().get(Integer.parseInt(input)).getTopic());
                System.out.println("Conetent: "+list.get(i).getEmail().getInbox().get(Integer.parseInt(input)).getContent());
                
                System.out.print("\n\nInput anything to continue...");
                input = reader.readLine(); 
                break;
            }
            }
            if (noEmails == true)
            {
                System.out.println("No Emails...");
            }      
                
            }

        private void deleteEmail(ArrayList <Employee> list, String user) throws IOException
        {
            System.out.println("****DELTE***** \n\n");
            boolean noEmails = true;
            
            for (int i = 0; i < list.size();i++)
            {
                for (int j = 0; j <list.get(i).getEmail().getInbox().size();j++)
                {
                    if(list.get(i).getId().equals(user))
                    {
                         System.out.println(j+". "+list.get(i).getEmail().getInbox().get(j).getSender().getAddress()+"  -  Date: "+list.get(i).getEmail().getInbox().get(j).getDate());
                         noEmails = false;
                              
                    }
                } 
            if(noEmails == false){
                System.out.println("Pick an Email to Delete \n\n");
                String input = reader.readLine();
               list.get(i).getEmail().getInbox().remove(i);   
                System.out.print("\n\nEmail Deleted...");
                break;
            }
            }
            if (noEmails == true)
            {
                System.out.println("No Emails...");
            }      
  
        }
           
        
}

    

