/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

/**
 *
 * @author Diogo
 */
public class Employee {
    
    String name;
    int permissions;
    EmailAddress email;

    public String getName() {
        return name;
    }

    public int getPermissions() {
        return permissions;
    }

    public EmailAddress getEmail() {
        return email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPermissions(int permissions) {
        this.permissions = permissions;
    }

    public void setEmail(EmailAddress email) {
        this.email = email;
    }
    
    
    
    
}
