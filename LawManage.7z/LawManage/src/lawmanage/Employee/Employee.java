/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage.Employee;

import lawmanage.Email.EmailAddress;

/**
 *
 * @author Diogo
 */
abstract public class Employee {
    protected String id;
    protected String name;
    protected int permissions;
    protected EmailAddress email;

    public String getName() {
        return name;
    }

    public int getPermissions() {
        return permissions;
    }

    public EmailAddress getEmail() {
        return email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPermissions(int permissions) {
        this.permissions = permissions;
    }

    public void setEmail(EmailAddress email) {
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    
    
    
}
