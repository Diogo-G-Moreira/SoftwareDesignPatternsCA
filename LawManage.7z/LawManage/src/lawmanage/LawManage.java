/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import java.io.IOException;
import java.text.ParseException;

/**
 *
 * @author Diogo
 * 
 * 
 * Runs login and Calendar, incoorperates singleton for both so constructers are not run again. 
 * 
 * 
 * 
 * 
 */
public class LawManage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException, IOException {

        Login login = null;
        login = login.getInstance();
        MyCalendar calendar = null;
        calendar = calendar.getInstance();
        while (true) {
            String id = login.login();
            calendar.calendarInterface(id);
        }

    }

}
