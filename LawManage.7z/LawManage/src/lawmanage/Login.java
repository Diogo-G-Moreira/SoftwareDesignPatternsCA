/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import java.util.Scanner;

/**
 *
 * @author Diogo
 */
public class Login {
    
    private static Login firstInstance = null;
    String[] userArray = {"lawyer1","secretary1", "accountant1"};
    String[] passArray = {"lawyer","secretary", "accountant"};
    String[] idArray = {"00001","00002", "00003"};
    String selectedId;
    Scanner user_input;
    private Login() {
        user_input = new Scanner( System.in );
        
        
    }
    public String login()
    {
        System.out.println("Law Management System - Taveres & Associates");
        boolean success = false;
        while(true){
        System.out.print("Username: ");
        String userName = user_input.next();
        System.out.print("Password: ");
        String password = user_input.next();
        
        for (int i = 0; i < userArray.length; i++)
        {
            if(userName.equals(userArray[i]) && password.equals(passArray[i]))
            {
                success = true;
                selectedId = idArray[i];
            }
        
        }
        if(success ==true)
        {
            return selectedId;
        }
        }
    }
    
    public static Login getInstance()
    {
     if(firstInstance==null){
         firstInstance = new Login();
     }   
     return firstInstance;
    }
    
    
    
    
}
