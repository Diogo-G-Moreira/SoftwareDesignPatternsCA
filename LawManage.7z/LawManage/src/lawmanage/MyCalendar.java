/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

import lawmanage.Email.EmailManager;
import lawmanage.Email.EmailAddress;
import lawmanage.Appointment.AppointmentManager;
import lawmanage.Appointment.Appointment;
import lawmanage.Employee.Secretary;
import lawmanage.Employee.Lawyer;
import lawmanage.Employee.Accountant;
import lawmanage.Employee.Employee;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;
import org.joda.time.DateTime;

/**
 *
 * @author Diogo
 * 
 * 
 * Main Interface
 * Will output a calendar, saying which appointments are on which days
 * 
 * Has a menu to allow the user to choose what they want to do.
 * This can be appointment manager, or Email Manager,
 * 
 */
public class MyCalendar {

    private static MyCalendar firstInstance = null;
    ArrayList<Appointment> appList;
    ArrayList<Employee> empList;
    String user;

    private MyCalendar() throws ParseException {

        appList = new ArrayList<>();
        empList = new ArrayList<>();
        initilize();

    }

    public static MyCalendar getInstance() throws ParseException {
        if (firstInstance == null) {
            firstInstance = new MyCalendar();
        }
        return firstInstance;
    }

    
    /*
    *
    *Outputs the calendar, and the menu choices.  Will also take the choice and run it.
    *
    */
    
    public void calendarInterface(String id) throws ParseException, IOException {
        Scanner user_input = new Scanner(System.in);
        user = loggedInUser(id);
        System.out.println("\n\nCALENDAR");
        DateTime days = new DateTime(2017, 1, 1, 0, 0, 0);
        displayCalendar(days);
        boolean end = false;
        while (true) {
            System.out.println("Would you like to...\n1.Edit Appointments\n2.Next Month\n3.Last Month \n4.Edit Emails\n5.Exit");
            String input = user_input.next();
            System.out.println("\n\n\n\n\n\n\n\n\n");

            switch (input) {
                case "1":
                    new AppointmentManager(appList, empList);
                    break;
                case "2":
                    if (days.getMonthOfYear() == 12) {
                        days = days.plusYears(1);
                    } else {
                        days = days.plusMonths(1);
                    }
                    displayCalendar(days);
                    break;
                case "3":
                    if (days.getMonthOfYear() == 1) {
                        days = days.minusYears(1);
                    } else {
                        days = days.minusMonths(1);
                    }
                    displayCalendar(days);
                    break;
                case "4":
                    new EmailManager(appList, empList, user);
                    break;
                case "5":
                    end = true;
                    break;
                default:
                    System.out.println("Invalid Choice, Try Again");
                    break;
                    
            }
            if(end==true)
            {
                break;
            }
        }
    }

    /*
    * Sets up initial accounts and appointments
    *
    */
    private void initilize() throws ParseException {

        empList.add(new Lawyer("Elliott Wendland", new EmailAddress("wendland@t&co.com"), "00001"));
        empList.add(new Secretary("Donna Cortes", new EmailAddress("cortes@t&co.com"), "00002"));
        empList.add(new Lawyer("Marissa Bullen", new EmailAddress("bullen@t&co.com"), "00004"));
        empList.add(new Lawyer("Adena Mulcahy", new EmailAddress("mulcahy@t&co.com"), "00005"));
        empList.add(new Accountant("Ethan Valliere", new EmailAddress("valliere@t&co.com"), "00003"));
        empList.add(new Accountant("Sophie Mora", new EmailAddress("mora@t&co.com"), "00006"));
        empList.add(new Secretary("Elliot Hazley", new EmailAddress("hazley@t&co.com"), "00007"));
        empList.add(new Secretary("Bernardina Casali", new EmailAddress("casali@t&co.com"), "00008"));
        empList.add(new Accountant("Mike Paik", new EmailAddress("paik@t&co.com"), "00010"));
        empList.add(new Accountant("Destiny Lasso", new EmailAddress("lasso@t&co.com"), "00009"));

        appList.add(new Appointment("Shareholders meeting", "Meeting with Shareholders.", new DateTime(2017, 1, 3, 0, 0, 0)));
        appList.add(new Appointment("Court Date for Case 00542", "YtSAztGXhMnaCjCPkKyJR", new DateTime(2017, 1, 4, 0, 0, 0)));
        appList.add(new Appointment("Court Date for Case 00544", "YtSAztGXhMnaCjCPkKyJR.", new DateTime(2017, 1, 7, 0, 0, 0)));
        appList.add(new Appointment("Case 00542 interview", "YtSAztGXhMnaCjCPkKyJR", new DateTime(2017, 1, 16, 0, 0, 0)));
        appList.add(new Appointment("Shareholders meeting", "YtSAztGXhMnaCjCPkKyJR.", new DateTime(2017, 1, 19, 0, 0, 0)));
        appList.add(new Appointment("General meeting", "YtSAztGXhMnaCjCPkKyJR.", new DateTime(2017, 2, 13, 0, 0, 0)));
        appList.add(new Appointment("Court Date for Case 00544 meeting", "YtSAztGXhMnaCjCPkKyJR", new DateTime(2017, 2, 18, 0, 0, 0)));
        appList.add(new Appointment("Shareholders meeting", "YtSAztGXhMnaCjCPkKyJR", new DateTime(2017, 3, 1, 0, 0, 0)));

    }

    /*
    *Displays calendar and appointments
    *
    */
    
    private void displayCalendar(DateTime days) {

        for (int i = 0; i < days.dayOfMonth().getMaximumValue(); i++) {
            boolean dateCheck = false;
            for (int j = 0; j < appList.size(); j++) {
                if (appList.get(j).getDate().isEqual(days.plusDays(i))) {
                    System.out.println(days.plusDays(i).toString("yyyy-MMM-dd") + "------" + appList.get(j).getTypeMeeting());
                    dateCheck = true;
                }
            }
            if (dateCheck != true) {
                System.out.println(days.plusDays(i).toString("yyyy-MMM-dd"));
            }

        }

    }

    /*
    * Determines who is logged in
    *
    */
    
    private String loggedInUser(String id) {

        for (int i = 0; i < empList.size(); i++) {
            if (empList.get(i).getId().equals(id)) {
                return id;
            }

        }
        return null;
    }

}
