/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lawmanage;

/**
 *
 * @author Diogo
 */
public class Secretary extends Employee {
    
    public Secretary(String name, EmailAddress email, String id)
    {
        this.name = name;
        this.email = email;
        this.id = id;
        permissions = 1;
    }
    
    
    
    
}
   
